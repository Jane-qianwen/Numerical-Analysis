
x=zeros(1,5)  #define two Matrix to store datas
arf=zeros(1,10)
function p(n) # chose different Xs depending on h
   h=1/n;
  for i=1:1:n+1
     x[i]=1+(i-1)*h
    i=i+1;
  end
end
arf2=[1/3,4/3,1/4]
arf3=[3/8,9/8,9/8,3/8]
arf4=[14/45,64/45,24/45,64/45,14/45]
function geta(n) #to chose coefficients depending on n
  if n==2
    arf=arf2'
  else
    if n==3
    arf=arf3'
    else
      if n==4
     arf=arf4'
        return arf
      end
    end
  end
end
f(x)=1/x;
function NC(n)  # define the form
   va=0;
   h=1/n
   u=geta(n);
   p(n);
   for i=1:1:n+1
    va=h*f(x[i])*u[i]+va;
  end
    return va
end



