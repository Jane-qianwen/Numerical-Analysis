x=zeros(1,5) #define several Matrixs to store datas
r=zeros(1,5)
c=zeros(1,5)
r2=[0.5773502692,-0.5773502692]
r3=[0.7745966692,0,-0.7745966692]
r4=[0.8611363116,0.3399810436,-0.3399810436,-0.8611363116]
c2=[1,1]
c3=[0.5555555556,0.888888889,0.5555555556]
c4=[0.34785484,0.6521451549,0.6521451549,0.34785484]
function getr(n) #chose r depend on n
  if n==2
      r=r2'
    else
      if n==3
      r=r3'
       else
         if n==4
            r=r4'
      end
    end
  end
end
function getc(n)#chose n depend on n
   if n==2
       c=c2'
  else
    if n==3
       c=c3'
    else
      if n==4
        c=c4'
      end
    end
  end
end
f(x)=1/x;
function G(n) #By transform the interval from [1,2] to [-1,1],the funtion becomes 1/f(x+3)
  va=0;
  s=getr(n);
  p=getc(n);
   for i=1:1:n
     va=f(s[i]+3)*p[i]+va
    i=i+1
  end
    return va
  end



