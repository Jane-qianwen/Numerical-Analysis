inputfunc = @exp; %define an anonymous fuction
H=[]; %define an empty vector to store all h
ERROR=[]; %define an empty vector to store all the difference
true_answer=1;
for h=10^(-15):10^(-4):10^(-1)
    difference=mydiff(inputfunc,0,h);
    error=abs(difference-true_answer);
    H=[H;h]%append the new h
    ERROR=[ERROR;error];%append the new error
end
figure(1)
plot(H,ERROR);
xlabel('h');
ylabel('error');
ylim([0,0.004]);
title('problem 3b')
function difference = mydiff(f,x,h)
    difference=(f(x+h)-f(x-h))/(2*h);
end


    