function [v] = GramSchmidt(A)
v(:,1)=A(:,1)/norm(A(:,1)) %nomalize the first column
[row,col] = size(A); %definde the size of input matrix
for j = 2:col
    sum(:,1)=zeros(1,row); %variable for the later sum
    for i = 1:j-1
        h(i,j)=A(:,j)'*v(:,i);
         sum(:,1) =sum(:,1)+h(i,j)*v(:,i); %update the sum
    end
    v(:,j)=A(:,j)-sum(:,1); %Orthogonalization
    v(:,j)=v(:,j)/norm(v(:,j)); %normalization
end

