import Base.+	#To avoid conflict when define the +,*,sin,cos function.
import Base.*
import Base.sin
import Base.cos

type ADV	#There are 2 types of parameter.”ori” is the original function,”der” is the derived function.
	ori::Function
	der::Function
end

function +(A::ADV,B::ADV)	#for adding, the derivative is (derivative of a) + (derivative of b).
	out(x)=A.ori(x)+B.ori(x)
	dout(x)=A.der(x)+B.der(x)
	return ADV(out,dout);
end

function *(A::ADV,B::ADV)	#According to the chain rule, if a function is multiplied by another, the derivative is as follows.
	out(x)=A.ori(x)*B.ori(x)
	dout(x)=A.ori(x)*B.der(x)+A.der(x)*B.ori(x)
	return ADV(out,dout);
end

function sin(A::ADV)	#Define the sine function in the case of sin(Function).
	out(x)=sin(A.ori(x))
	dout(x)=cos(A.ori(x))*A.der(x)
	return ADV(out,dout);
end

function cos(A::ADV)	#Define the cosine function in the case of cos(Function).
	out(x)=cos(A.ori(x))
	dout(x)=(-1)*sin(A.ori(x))*A.der(x)
	return ADV(out, dout);
end

function +(A::ADV,B::Number) #In the case of a function plus a constant.
	out(x)=A.ori(x)+B
	dout(x)=A.der(x)+B
	return ADV(out, dout);
end

function +(A::Number,B::ADV) #In the case of a constant plus a function.
	out(x)=A+B.ori(x)
	dout(x)=A+B.der(x)
	return ADV(out, dout);
end

function *(A::ADV,B::Number)	#In the case of a function multiplying a constant.
	out(x)=A.ori(x)*B
	dout(x)=A.der(x)*B
	return ADV(out,dout);
end

function *(A::Number,B::ADV)	#In the case of a constant multiplying a function.
	out(x)=A*B.ori(x)
	dout(x)=A*B.der(x)
	return ADV(out,dout);
end

function ADforward(f::Function)
		#If f(x) is a constant, its derivative must be 0 for any x.
	obj(x)=x
  newobj(x)=1
  Z=ADV.(obj,newobj)
  result=f(Z)
  return result
end
