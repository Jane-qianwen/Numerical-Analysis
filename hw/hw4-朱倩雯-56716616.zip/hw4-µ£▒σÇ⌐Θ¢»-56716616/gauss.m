Q=[]; %store all the orthogonal basis
syms x 
g=1./(1+x.^2);         %original function
f(x)=0*x;%the start form of f(x)
for i=0:1:11
    denom = @(x) diff((1/25*x.^2-1).^i,i).^2;
    ai = (1/int(denom,x,-5,5))^(1/2);%find ai which minimize the gauss square
    Q=[Q;ai*diff((1/25*x.^2-1).^i,i)];
    f_qi =@(x) 1/(1+x.^2) * ai*diff((1/25*x.^2-1).^i,i);
    ci= int(f_qi,x,-5,5);
    f(x) = f(x)+ci*ai*diff((1/25*x.^2-1).^i,i);
end
m=@(x) Q*Q';
int(m,x,-5,5);
x=-5:0.1:5;
y=subs(g,x);           %��x����ԭ����f��
plot(x,y,'b'); hold on;
plot(x,f(x),'r'); hold off;
xlabel('x');
ylabel('p(x)');
legend('original function','Gauss approximation');
title('Gauss Approximation');



