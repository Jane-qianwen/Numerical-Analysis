
function s = natural_spline(f,a,b,N,x)
    h=(b-a)/N;%get equal-distant points
    r=[];
    for i =1:1:N-1
        ri=3*(f(a+(i+1)*h)-2*f(a+i*h)+f(a+(i-1)*h))/h;
        r=[r;ri];
    end
    v1=ones(1,N-1);
    v2=ones(1,N-2);
    H=diag(v1)*4*h+diag(v2,1)*h+diag(v2,-1)*h;
    c=inv(H)*r;
    A=[];B=[];D=[];
    for i=1:1:N
        ai=f(a+(i-1)*h);
        A=[A;ai];
        if i==N
            di = -c(N-1)/(3*h);
            bi = (f(a+i*h)-f(a+(i-1)*h))/h - 2*c(N-1)*h/3;
        elseif i==1
            di=c(i)/(3*h); 
            bi = (f(a+i*h)-f(a+(i-1)*h))/h - c(i)*h/3;
        else
            di=(c(i)-c(i-1))/(3*h);
            bi = (f(a+i*h)-f(a+(i-1)*h))/h-(c(i)+2*c(i-1))*h/3;
        end
        B=[B;bi];
        D=[D;di];
    end
    A;B;D;
    c;
    C=[0;c];
    n=floor((x-a)/h);
    s=A(n+1) + B(n+1)*(x-(a+n*h)) + C(n+1)*(x-(a+n*h))^2 + D(n+1)*(x-(a+n*h))^3;
end
    

    
    
    
    