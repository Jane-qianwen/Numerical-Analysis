f=@(x) 1/(1+x^2);
S=[];
Z=[];
for x=-5:0.1:4.95
 s = natural_spline(f,-5,5,10,x);
 S=[S;s];
 z=1/(1+x^2);
 Z=[Z;z];
end
x=-5:0.1:4.9;
y=subs(f,x);  
plot(x,y,'b'); hold on;
plot(x,S,'r'); hold off;
legend('original function','natural spline');
xlabel('x');
ylabel('piecewise s');